package com.priceyar.widget

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Context

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(this@MainActivity), "AndroidBridge")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private class Bridge(context: Context) {
        private val store = SharedStore(context)
        private val appContext = context.applicationContext

        @JavascriptInterface
        fun loadData(): String = store.load()

        @JavascriptInterface
        fun saveData(value: String) {
            store.save(value)
            PriceWidgetProvider.refresh(appContext)
        }
    }
}
