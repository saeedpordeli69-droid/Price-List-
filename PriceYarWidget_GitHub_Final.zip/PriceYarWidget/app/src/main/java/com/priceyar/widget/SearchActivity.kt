package com.priceyar.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

class SearchActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var out: TextView
    private lateinit var store: SharedStore

    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        store = SharedStore(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xEE111111.toInt())
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        input = EditText(this).apply {
            hint = "جستجوی کالا..."
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
            textSize = 18f
            singleLine = true
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        out = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 19f
            setPadding(4, 22, 4, 4)
            gravity = Gravity.RIGHT
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 60))
        root.addView(out, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { find(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        find("")
    }

    private fun find(query: String) {
        try {
            val root = JSONObject(store.load())
            val stores = root.getJSONArray("stores")
            val active = root.optInt("active", 0).coerceIn(0, stores.length() - 1)
            val items = stores.getJSONObject(active).getJSONArray("items")
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val product = item.optString("name")
                if (query.isBlank() || product.contains(query, ignoreCase = true)) {
                    val price = item.optString("price")
                    out.text = "$product   $price"
                    push(product, price)
                    return
                }
            }
            out.text = if (query.isBlank()) "نام کالا را وارد کن" else "کالایی پیدا نشد"
            push("", "")
        } catch (_: Exception) {
            out.text = "اطلاعاتی برای جستجو پیدا نشد"
            push("", "")
        }
    }

    private fun push(name: String, price: String) {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, PriceWidgetProvider::class.java))
        ids.forEach { PriceWidgetProvider.update(this, manager, it, name, price) }
    }
}
