package com.priceyar.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class PriceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        update(context, manager, appWidgetId)
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, PriceWidgetProvider::class.java))
            ids.forEach { update(context, manager, it) }
        }

        fun update(context: Context, manager: AppWidgetManager, id: Int, name: String = "", price: String = "") {
            val views = RemoteViews(context.packageName, R.layout.widget_price)
            val opts = manager.getAppWidgetOptions(id)
            val width = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180)
            val height = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 56)
            val textSize = (12f + ((width - 120).coerceAtLeast(0) / 80f)).coerceIn(12f, 19f)
            val iconSize = (26 + ((height - 48).coerceAtLeast(0) / 16)).coerceIn(26, 40)
            views.setTextViewTextSize(R.id.query, android.util.TypedValue.COMPLEX_UNIT_SP, textSize)
            views.setTextViewTextSize(R.id.price, android.util.TypedValue.COMPLEX_UNIT_SP, (textSize + 1).coerceAtMost(20f))
            views.setImageViewResource(R.id.icon, R.drawable.ic_search)
            views.setViewVisibility(R.id.price, if (price.isBlank()) View.GONE else View.VISIBLE)
            views.setTextViewText(R.id.query, if (name.isBlank()) "جستجوی کالا..." else name)
            if (price.isNotBlank()) views.setTextViewText(R.id.price, price)

            val intent = Intent(context, SearchActivity::class.java)
            val pending = PendingIntent.getActivity(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
