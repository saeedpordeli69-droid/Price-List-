package com.priceyar.widget

import android.content.Context

class SharedStore(context: Context) {
    private val prefs = context.getSharedPreferences("priceyar_shared", Context.MODE_PRIVATE)
    fun load(): String = prefs.getString("data", DEFAULT) ?: DEFAULT
    fun save(value: String) { prefs.edit().putString("data", value).apply() }

    companion object {
        const val DEFAULT = "{\"active\":0,\"stores\":[{\"id\":null,\"name\":\"سوپر مارکت سلطانی\",\"items\":[]}]}"
    }
}
